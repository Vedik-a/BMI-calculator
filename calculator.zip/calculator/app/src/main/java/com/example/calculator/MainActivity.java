package com.example.calculator;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
       setContentView(R.layout.activity_main);

        EditText height,weight,heightin;
        TextView txtResult;
        Button btncal;

        height  = findViewById(R.id.height);
        weight  = findViewById(R.id.weight);
        heightin= findViewById(R.id.heightin);
        btncal = findViewById(R.id.btncal);
        txtResult = findViewById(R.id.txtResult);

        btncal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               int h = Integer.parseInt(height.getText().toString());
                int w = Integer.parseInt(weight.getText().toString());
                int i =  Integer.parseInt(heightin.getText().toString());

                int total = h*12 +i;
                double totalcm = total*2.53;
                double totalm = totalcm/100;
                double bmi = w/(totalm*totalm);
                if (bmi>25)
                {
                  txtResult.setText("overweight");
                }
                else if (bmi<18){
                    txtResult.setText("underweight");
                }
                else{
                    txtResult.setText("healthy");
                }
            }
    });
    } 
}